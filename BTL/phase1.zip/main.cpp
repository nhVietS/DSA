#include <iostream>
// #include "list/SLinkedList.h"
using namespace std;

int main() {
    /* YOUR CODE TO CHECK
     * Note: you should not submit this file. 
     * It should be only used to verify your implementation.
     */

    /* For example:

    SLinkedList<int>* list = new SLinkedList<int>();
    list->add(1);
    list->add(2);
    list->add(3);
    list->add(4);
    list->add(5);

    cout << list->toString() << endl;

     */
}